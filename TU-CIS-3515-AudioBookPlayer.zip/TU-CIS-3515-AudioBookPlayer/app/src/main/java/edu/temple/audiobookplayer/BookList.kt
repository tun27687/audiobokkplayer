package edu.temple.audiobookplayer

import android.os.Parcel
import android.os.Parcelable

data class BookList(
    var books: ArrayList<Book> = ArrayList(),
) : Parcelable {
    constructor(parcel: Parcel) : this(
        // this works
        arrayListOf<Book>().apply {
            parcel.readArrayList(Book::class.java.classLoader)
        }

        // this works but claims the cast will never work
//        parcel.readTypedList(ArrayList<Book>(), Book) as ArrayList<Book>

        // this works but complains about an unchecked cast
//        parcel.readArrayList(Book::class.java.classLoader) as ArrayList<Book>
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeTypedList(books)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<BookList> {
        override fun createFromParcel(parcel: Parcel): BookList {
            return BookList(parcel)
        }

        override fun newArray(size: Int): Array<BookList?> {
            return arrayOfNulls(size)
        }

        /**
         * Generates a BookList with a hard coded set of Book objects.
         */
        fun generateBooks(): BookList {
            val books = BookList()

            books.add(Book(" Anathem", "Neal Stephenson"))
            books.add(Book("The Forever War", "Joe Haldeman"))
            books.add(Book(" The Hitchhiker's Guide to the Galaxy series ", "Douglas Adams"))
            books.add(Book("The Murderbot Diaries series", "Isaac Asimov"))
            books.add(Book("The Foundation series", "Isaac Asimov"))
            books.add(Book("The Three-Body Problem series", "Liu Cixin"))
            books.add(Book("The Hyperion series ", "Dan Simmons"))
            books.add(Book(" Brave New World ", "Aldous Huxley"))
            books.add(Book("Children of Time", "Adrian Tchaikovsky"))
            books.add(Book("The Expanse", "James Corey and Ty Franck"))

            return books
        }
    }

    /**
     * collection-like operations
     */

    val size: Int
        get() = books.size

    fun add(element: Book) {
        books.add(element)
    }

    fun remove(element: Book) {
        books.remove(element)
    }

    operator fun get(index: Int): Book {
        return books[index]
    }
}
